package qwr.sysType;

public enum TypeSystem {
	FIRESECURITY,//пожарная сигнализация
	SECURITY,//охрана
	ACCESS,//доступ
	FIREFING,//пожаротушение
	VENT//вентиляция
}
