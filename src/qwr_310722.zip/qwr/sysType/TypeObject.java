package qwr.sysType;

public enum TypeObject {
	SWITCH,//геркон
	TEMPER,//температурный
	SMOKE,//дымовой
	VOLUME,//объемный
	BEAM,//лучевой
	VIBRATION,//трибе
	THREAD,//нить
	AREA,//область
	DOOR,//дверь
	GATEWAY//шлюз
}//enum TypeObject
