package qwr.sysType;

public enum ObjectStatus {
	NOTUSE,//не использовать
	NORMAL,//нормально
	FAULT,//авария
	ATTENT,//внимание
	ALARM,//тревога
	BLOCK,//блокировка
	PASS//проход
	//замкнуто
	//разомкнуто
}//enum ObjectStatus
