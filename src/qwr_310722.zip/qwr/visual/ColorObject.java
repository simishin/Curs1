package qwr.visual;

import qwr.sysType.ObjectStatus;
import qwr.sysType.TypeObject;
import qwr.sysType.TypeSystem;

class ColorObject {
	int color;
	ObjectStatus objStat;
	TypeObject objTyp;
	TypeSystem objSys;
}//class ColorObject
